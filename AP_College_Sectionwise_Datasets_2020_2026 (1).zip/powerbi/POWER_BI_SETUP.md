# Power BI Desktop — setup and chart guide

## Important
No native `.pbix` file is included, because the proprietary Power BI Desktop report format cannot be created and validated with the tools used here. The CSV tables, theme, DAX formulas, and layout instructions are ready to import into Power BI Desktop on Windows.

Data is **synthetic / fictional**. College-to-branch assignments are illustrative, not independently verified. AcademicYear 2020 means 2020–21; 2026 means 2026–27. Multi-year totals count annual student snapshots, not unique people.

## Import data

1. Open Microsoft Power BI Desktop.
2. Home -> Get data -> Text/CSV. Import the following from `data/master`:
   - `FactEnrollment_GenderLong.csv` -> query **FactEnrollment**
   - `DimCollege.csv` -> **DimCollege**
   - `DimProgram.csv` -> **DimProgram**
   - `DimAcademicYear.csv` -> **DimAcademicYear**
   - `DimSection.csv` -> **DimSection**
   - `DimStudyYear.csv` -> **DimStudyYear**
3. Use **Transform Data** and set AcademicYear, StudyYear, Students, and SortOrder/DisplayOrder to whole number where applicable.
4. Choose Close & Apply.
5. In Model view, create *one-to-many, single-direction* relationships from each dimension to FactEnrollment:

   | One-side dimension column | Many-side fact column |
   |---|---|
   | DimCollege[CollegeID] | FactEnrollment[CollegeID] |
   | DimProgram[ProgramID] | FactEnrollment[ProgramID] |
   | DimAcademicYear[AcademicYear] | FactEnrollment[AcademicYear] |
   | DimSection[Section] | FactEnrollment[Section] |
   | DimStudyYear[StudyYear] | FactEnrollment[StudyYear] |

Do **not** add DimProgram->DimCollege as a separate relationship. This would introduce an ambiguous filter path because both dimensions already connect directly to the fact.

6. In Report view, View -> Themes -> Browse for themes, then choose `powerbi/AP_Education_PowerBI_Theme.json`.
7. Go to Modeling -> New measure and paste each measure from `powerbi/DAX_Measures.txt`. Percentage measures should be formatted as Percentage.

## Suggested report pages

**Page 1 — Executive Dashboard**
- Cards: [Total Students], [Male Students], [Female Students], [Colleges], [Class Sections].
- Stacked column chart: Axis `DimAcademicYear[AcademicYear]`, Legend `FactEnrollment[Gender]`, Values [Total Students].
- Doughnut chart: Legend `FactEnrollment[Gender]`, Values [Total Students].
- Clustered bar chart: Axis `DimSection[Section]`, Legend `FactEnrollment[Gender]`, Values [Total Students].
- Matrix: Rows `DimCollege[CollegeType]`, Columns `DimAcademicYear[AcademicYear]`, Values [Total Students].

**Page 2 — B.Tech Analysis**
- Apply page filter `DimCollege[CollegeType] = B.Tech`.
- Branch chart: Axis `DimProgram[BranchName]`, Values [Total Students].
- Year-wise gender stacked chart, District bar chart, StudyYear by Section heatmap / matrix.

**Page 3 — Degree College Analysis**
- Apply page filter `DimCollege[CollegeType] = Degree`.
- Use the same visual types and branch/year slicers.

**Page 4 — Section Explorer**
- Slicers: `DimSection[Section]` (A/B/C), `DimAcademicYear[AcademicYear]` (2020–2026), `DimStudyYear[StudyYear]`, `DimCollege[CollegeName]`.
- Matrix rows: AcademicYear, StudyYear, Section; Columns: Gender; Values: [Total Students].
- Heatmap: Matrix section vs year, with background conditional formatting on values.

**Page 5 — District & College Leaderboard**
- Top-N bar chart: Axis `DimCollege[District]`, Values [Total Students].
- Table: CollegeName, District, CollegeType, [Male Students], [Female Students], [Total Students].
- Drill-through on CollegeName and Program name.

## Recommended slicers (sync across all pages)
AcademicYear; CollegeType; District; CollegeName; BranchName; StudyYear; Section; Gender.

## CSV file alternatives
- For a one-table quick report, import `data/master/All_College_Class_Records_2020_2026.csv` (already enriched with names, gender columns, class/year/section).
- For easiest pie charts and correct gender filtering, prefer `FactEnrollment_GenderLong.csv` plus dimensions.
- `data/by_year_section/BTech` and `data/by_year_section/Degree` contain **42** individually split section files (7 years x 3 sections x 2 college types).
- `data/by_year` contains **14** year-specific files.
- `data/by_section` contains **6** section-specific files.
- `data/summaries` contains five precomputed chart tables.

## Example data validation
After importing, the full fact table should contain 35,560 rows (each of 17,780 class records split into Male and Female). Total synthetic student snapshots across all academic years: **795,551** (Male 393,797; Female 401,754). The source workbook and CSV summaries should match.
