"""Build REPRODUCIBLE, SYNTHETIC demo enrolment data for AP dashboard.
College names are a curated illustrative directory, not a complete/verified 2026 register.
Program availability and ALL STUDENT COUNTS are fictional demonstration values.
No external network or additional dependencies needed.
"""
from pathlib import Path
import csv
import random

ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'data'
DATA.mkdir(exist_ok=True)
R = random.Random(20261101)

DISTRICTS = [
    'Alluri Sitharama Raju','Anakapalli','Ananthapuramu','Annamayya','Bapatla',
    'Chittoor','Dr. B.R. Ambedkar Konaseema','East Godavari','Eluru','Guntur',
    'Kakinada','Krishna','Kurnool','Markapuram','Nandyal','NTR','Palnadu',
    'Parvathipuram Manyam','Polavaram','Prakasam','Sri Potti Sriramulu Nellore',
    'Sri Sathya Sai','Srikakulam','Tirupati','Visakhapatnam','Vizianagaram',
    'West Godavari','YSR Kadapa'
]

# Display name, current (2026) district, city, women-only status.
# Names are selected illustrative examples, NOT a full APSCHE database.
ENGINEERING = [
('Dr. K. V. Subba Reddy Institute of Technology','Kurnool','Kurnool',False),
('G. Pulla Reddy Engineering College','Kurnool','Kurnool',False),
('Rajeev Gandhi Memorial College of Engineering and Technology','Nandyal','Nandyal',False),
('Santhiram Engineering College','Nandyal','Nandyal',False),
('SVR Engineering College','Nandyal','Nandyal',False),
('JNTUA College of Engineering Anantapur','Ananthapuramu','Anantapur',False),
('Srinivasa Ramanujan Institute of Technology','Ananthapuramu','Anantapur',False),
('PVKK Institute of Technology','Ananthapuramu','Anantapur',False),
('Madanapalle Institute of Technology & Science','Annamayya','Madanapalle',False),
('Annamacharya Institute of Technology & Sciences, Rajampet','Annamayya','Rajampet',False),
('Sri Venkateswara University College of Engineering','Tirupati','Tirupati',False),
('Sree Vidyanikethan Engineering College','Tirupati','Tirupati',False),
('Audisankara College of Engineering & Technology','Tirupati','Gudur',False),
('Narayana Engineering College, Nellore','Sri Potti Sriramulu Nellore','Nellore',False),
('Geethanjali Institute of Science and Technology','Sri Potti Sriramulu Nellore','Nellore',False),
('JNTUK University College of Engineering Kakinada','Kakinada','Kakinada',False),
('Aditya Engineering College','Kakinada','Surampalem',False),
('Pragati Engineering College','Kakinada','Surampalem',False),
('Godavari Institute of Engineering & Technology','East Godavari','Rajamahendravaram',False),
('Sagi Rama Krishnam Raju Engineering College','West Godavari','Bhimavaram',False),
('Vishnu Institute of Technology','West Godavari','Bhimavaram',False),
('Shri Vishnu Engineering College for Women','West Godavari','Bhimavaram',True),
('Velagapudi Ramakrishna Siddhartha Engineering College','NTR','Vijayawada',False),
('Prasad V. Potluri Siddhartha Institute of Technology','NTR','Vijayawada',False),
('Lakireddy Bali Reddy College of Engineering','NTR','Mylavaram',False),
('RVR & JC College of Engineering','Guntur','Guntur',False),
('Vasireddy Venkatadri Institute of Technology','Guntur','Nambur',False),
('Vignan’s Lara Institute of Technology & Science','Guntur','Vadlamudi',False),
('Bapatla Engineering College','Bapatla','Bapatla',False),
('GMR Institute of Technology','Vizianagaram','Rajam',False),
('Maharaj Vijayaram Gajapathi Raj College of Engineering','Vizianagaram','Vizianagaram',False),
('Andhra University College of Engineering','Visakhapatnam','Visakhapatnam',False),
('Gayatri Vidya Parishad College of Engineering','Visakhapatnam','Visakhapatnam',False),
('Raghu Engineering College','Visakhapatnam','Visakhapatnam',False),
('Anil Neerukonda Institute of Technology & Sciences','Anakapalli','Sangivalasa',False),
('KSRM College of Engineering','YSR Kadapa','Kadapa',False),
('QIS College of Engineering & Technology','Prakasam','Ongole',False),
('ABR College of Engineering and Technology','Markapuram','Kanigiri',False),
]
DEGREE = [
('Silver Jubilee Government Degree College','Kurnool','Kurnool',False),
('St. Joseph’s Degree College','Kurnool','Kurnool',False),
('KVR Government Degree College for Women','Kurnool','Kurnool',True),
('Government Degree College, Nandyal','Nandyal','Nandyal',False),
('SSBN Degree College','Ananthapuramu','Anantapur',False),
('Government Degree College, Anantapur','Ananthapuramu','Anantapur',False),
('Government Degree College, Madanapalle','Annamayya','Madanapalle',False),
('Government Degree College, Palamaner','Chittoor','Palamaner',False),
('Sri Venkateswara Arts College','Tirupati','Tirupati',False),
('D.K. Government College for Women','Sri Potti Sriramulu Nellore','Nellore',True),
('V.R. College','Sri Potti Sriramulu Nellore','Nellore',False),
('Pithapur Rajah’s Government College','Kakinada','Kakinada',False),
('Aditya Degree & P.G. College for Women','Kakinada','Kakinada',True),
('Government Arts College, Rajamahendravaram','East Godavari','Rajamahendravaram',False),
('D.N.R. College','West Godavari','Bhimavaram',False),
('Aditya Degree College, Palakol','West Godavari','Palakollu',False),
('Sir C.R. Reddy College','Eluru','Eluru',False),
('Ch. S.D. St. Theresa’s College for Women','Eluru','Eluru',True),
('V.S.M. College','Dr. B.R. Ambedkar Konaseema','Ramachandrapuram',False),
('Andhra Loyola College','NTR','Vijayawada',False),
('S.R.R. & C.V.R. Government Degree College','NTR','Vijayawada',False),
('Maris Stella College','NTR','Vijayawada',True),
('Andhra Christian College','Guntur','Guntur',False),
('Hindu College, Guntur','Guntur','Guntur',False),
('Government College for Women, Guntur','Guntur','Guntur',True),
('Bapatla College of Arts & Sciences','Bapatla','Bapatla',False),
('Government Degree College, Narasaraopet','Palnadu','Narasaraopet',False),
('Government Degree College, Ongole','Prakasam','Ongole',False),
('Government Degree College, Markapuram','Markapuram','Markapuram',False),
('Government Degree College, Rampachodavaram','Polavaram','Rampachodavaram',False),
('Government Degree College, Paderu','Alluri Sitharama Raju','Paderu',False),
('Mrs. A.V.N. College','Visakhapatnam','Visakhapatnam',False),
('Dr. Lankapalli Bullayya College','Visakhapatnam','Visakhapatnam',False),
('Maharajah’s College','Vizianagaram','Vizianagaram',False),
('Government Degree College, Srikakulam','Srikakulam','Srikakulam',False),
('Government Degree College, Tekkali','Srikakulam','Tekkali',False),
('Government Degree College, Kadapa','YSR Kadapa','Kadapa',False),
('Government Degree College, Hindupur','Sri Sathya Sai','Hindupur',False),
('Government Degree College, Parvathipuram','Parvathipuram Manyam','Parvathipuram',False),
('Government Degree College, Machilipatnam','Krishna','Machilipatnam',False),
]
BTECH_PROGRAMS = [
('CSE','Computer Science & Engineering'),('AIML','Artificial Intelligence & Machine Learning'),
('CSD','Computer Science (Data Science)'),('ECE','Electronics & Communication Engineering'),
('EEE','Electrical & Electronics Engineering'),('MECH','Mechanical Engineering'),
('CIVIL','Civil Engineering'),('IT','Information Technology'),
('CYBER','Cyber Security'),('AI','Artificial Intelligence'),
('CHEM','Chemical Engineering'),('BIOTECH','Biotechnology')]
DEGREE_PROGRAMS = [
('BSC-CS','B.Sc. Computer Science'),('BSC-DS','B.Sc. Data Science'),
('BSC-MATH','B.Sc. Mathematics'),('BSC-PHYS','B.Sc. Physics'),
('BSC-CHEM','B.Sc. Chemistry'),('BSC-BOT','B.Sc. Botany'),
('BSC-ZOO','B.Sc. Zoology'),('BCOM-GEN','B.Com. General'),
('BCOM-CA','B.Com. Computer Applications'),('BA-ECO','B.A. Economics'),
('BA-POL','B.A. Political Science'),('BA-HIST','B.A. History'),
('BBA','Bachelor of Business Administration'),('BCA','Bachelor of Computer Applications')]
SOURCE_BTECH='https://cap.apcfss.in/DashboardHome'
SOURCE_DEGREE='https://oamdc.ucanapply.com/institute-wise-courses?appid=OAMDC'
SOURCE_DISTRICTS='https://igod.gov.in/sg/AP/E042/organizations'

def save(filename, columns, records):
    with (DATA/filename).open('w',newline='',encoding='utf-8-sig') as f:
        writer=csv.writer(f);writer.writerow(columns);writer.writerows(records)

college_rows=[]
program_rows=[]
enroll_rows=[]
for group,prefix,entries,candidates,src in [
    ('B.Tech','ENG',ENGINEERING,BTECH_PROGRAMS,SOURCE_BTECH),
    ('Degree','DEG',DEGREE,DEGREE_PROGRAMS,SOURCE_DEGREE)]:
    for idx,(name,district,city,women) in enumerate(entries,1):
        cid=f'{prefix}{idx:03d}'
        college_rows.append([cid,name,group,district,city,'Women-only' if women else 'Co-education',src,'Curated demo directory; verify institution name, district and active status'])
        # For each institution, courses are illustrative--not a verified course/branch list.
        if group=='B.Tech':
            chosen = [candidates[0],candidates[3]] + R.sample([x for x in candidates if x not in (candidates[0],candidates[3])], R.randint(3,5))
        else:
            chosen = [candidates[0],candidates[7]] + R.sample([x for x in candidates if x not in (candidates[0],candidates[7])], R.randint(3,5))
        for prog_code,prog_name in chosen:
            pid=f'{cid}-{prog_code}'
            program_rows.append([pid,cid,group,prog_code,prog_name,'Illustrative association: verify with the college'])
            for year in range(2020,2027):
                max_study=4 if (group=='B.Tech' or year>=2024) else 3
                for study in range(1,max_study+1):
                    # Variable one/two/three sections, deterministic by program and year
                    num_sections=2 if prog_code in ('CSE','AIML','ECE','BSC-CS','BCOM-GEN','BCA') else 1
                    if prog_code=='CSE' and (year>=2023):num_sections=3
                    for section in 'ABC'[:num_sections]:
                        scale=1 + 0.045*(year-2020)
                        base=R.randint(22,56)
                        total=max(12, int(round(base*scale + R.randint(-5,5))))
                        # female ratio plausible but entirely fictional; women-only counts are 100% female.
                        p_female=1.0 if women else (0.41 if group=='B.Tech' else 0.54)+R.uniform(-0.16,0.16)
                        female=total if women else min(total,max(0,int(round(total*p_female))))
                        male=total-female
                        enroll_rows.append([cid,pid,year,f'{year}-{str((year+1)%100).zfill(2)}',study,section,male,female,total,'SYNTHETIC - NOT OFFICIAL'])

save('colleges.csv',['college_id','college_name','college_type','district','city','campus_type','source_url','directory_note'],college_rows)
save('programs.csv',['program_id','college_id','college_type','branch_code','branch_name','verification_note'],program_rows)
save('enrollments_2020_2026.csv',['college_id','program_id','academic_year','academic_year_label','study_year','section','male','female','total','data_quality'],enroll_rows)
save('districts.csv',['district','district_status','source_url'],[[d,'Current 2026 district name; historical values mapped to present district geography',SOURCE_DISTRICTS] for d in DISTRICTS])
metadata=[
 ('directory','Curated examples, not exhaustive or verified for 2026; source links are official portals for cross-checking'),
 ('course_assignments','ILLUSTRATIVE: a listed course may not be offered by a particular college'),
 ('student_counts','100% SYNTHETIC/FICTIONAL; NOT actual admissions, enrollment or AISHE statistics'),
 ('academic_year','Start year of academic year (2020 means 2020-21, 2026 means 2026-27)'),
 ('study_year','Year within a degree/B.Tech programme; example 1=first year'),
 ('section','Class/section A, B, C (synthetic)'),
 ('male/female','Fictional aggregated male and female counts for example reporting only'),
 ('degree_4th_year','Synthetic example adds fourth-year degree sections starting 2024; not a verified campus program structure'),
 ('district_historical_mapping','All 2020-2026 records mapped to present-day 2026 district labels; NOT historical boundary-accurate'),
 ('years','2020, 2021, 2022, 2023, 2024, 2025, 2026 (all included)'),
 ('college_source','https://oamdc.ucanapply.com/institute-wise-courses?appid=OAMDC'),
 ('official_dashboard','https://cap.apcfss.in/DashboardHome'),
 ('district_source','https://igod.gov.in/sg/AP/E042/organizations'),
]
save('data_dictionary.csv',['field_or_topic','description'],metadata)
print('Created',len(college_rows),'college examples,',len(program_rows),'illustrative courses,',len(enroll_rows),'synthetic student records across 2020-2026')

# Extra separately downloadable category datasets (not just one combined file).
for category,prefix,slug in [('B.Tech','ENG','BTech'),('Degree','DEG','Degree')]:
    save(f'{slug}_colleges.csv',['college_id','college_name','college_type','district','city','campus_type','source_url','directory_note'],
         [row for row in college_rows if row[2]==category])
    save(f'{slug}_courses.csv',['program_id','college_id','college_type','branch_code','branch_name','verification_note'],
         [row for row in program_rows if row[2]==category])
    save(f'{slug}_enrollments_2020_2026.csv',['college_id','program_id','academic_year','academic_year_label','study_year','section','male','female','total','data_quality'],
         [row for row in enroll_rows if row[0].startswith(prefix)])

# Efficient annual summaries built from the underlying sample ledger.
col_by_id={r[0]:r for r in college_rows}
prog_by_id={r[0]:r for r in program_rows}
college_totals={}
branch_totals={}
district_totals={}
for row in enroll_rows:
    cid,pid,year=row[0],row[1],row[2]
    col=col_by_id[cid];prog=prog_by_id[pid]
    entries=[(college_totals,(year,cid,col[1],col[2],col[3])),
             (branch_totals,(year,col[2],prog[3],prog[4])),
             (district_totals,(year,col[3],col[2]))]
    for out,key in entries:
        arr=out.setdefault(key,[0,0,0])
        for i,j in enumerate((6,7,8)):arr[i]+=row[j]

save('college_year_gender_summary.csv',['academic_year','college_id','college_name','college_type','district','male','female','total'],
     [[*k,*v] for k,v in sorted(college_totals.items())])
save('branch_year_gender_summary.csv',['academic_year','college_type','branch_code','branch_name','male','female','total'],
     [[*k,*v] for k,v in sorted(branch_totals.items())])
save('district_year_gender_summary.csv',['academic_year','district','college_type','male','female','total'],
     [[*k,*v] for k,v in sorted(district_totals.items())])
