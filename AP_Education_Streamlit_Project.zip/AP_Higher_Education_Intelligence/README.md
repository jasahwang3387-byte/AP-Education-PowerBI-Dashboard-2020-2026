# Andhra Pradesh Higher Education Intelligence Dashboard

**Python + Streamlit + Plotly • Separate B.Tech and Degree-college views • 2020–2026**

## Important: data status

This project is a **working demonstration**, not an official Andhra Pradesh student-statistics service.

- The 78 college names form an **illustrative, non-exhaustive** directory; verify spelling, active status, and present district.
- The 477 college-to-course/branch assignments are **illustrative**. They **do not verify** that the institutions offer those branches.
- The **17,780** class/year/section enrollment rows, male counts, female counts, and student totals are **100% synthetic (fictional) demonstration data** for 2020–2026. DO NOT cite them as factual historical enrollment.
- Academic year 2020 refers to 2020–21, through 2026 for 2026–27.
- The district list uses **28 current (2026) AP districts**. Historical rows are displayed under present-day labels, which differs from actual pre-2026 district boundaries.

Official directories for replacing examples:
- https://cap.apcfss.in/DashboardHome
- https://oamdc.ucanapply.com/institute-wise-courses?appid=OAMDC
- https://cets.apsche.ap.gov.in/EAPCET/Eapcet/EAPCET_HomePage
- https://igod.gov.in/sg/AP/E042/organizations

## Files

```text
AP_Higher_Education_Intelligence/
├── app.py                           Interactive dashboard
├── requirements.txt                 Python dependencies
├── generate_dataset.py              Recreate demo CSV data (fixed seed)
├── README.md                        Setup and project documentation
└── data/
    ├── colleges.csv                 College catalog with type / district
    ├── programs.csv                 Illustrative college-wise courses
    ├── enrollments_2020_2026.csv    Synthetic male / female / class / year counts
    ├── districts.csv                28 current AP districts
    ├── data_dictionary.csv          Field meanings and data disclosure
    └── AP_College_Dashboard_Dataset_2020_2026.xlsx   Same data in sheets
```

## Run on a Windows laptop (PowerShell)

Install Python 3.11 or newer if not already installed.

1. Extract the ZIP to a convenient folder.
2. Open that folder, right-click → **Open in Terminal**, then run the following commands, one at a time:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

If activation is blocked by PowerShell policy, you can avoid activating the environment:

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m streamlit run app.py
```

Browser opens at **http://localhost:8501**. Stop the app using **Ctrl+C** in the terminal.

## Run on macOS / Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

## Features

- Executive overview: KPIs, gender doughnut, stacked yearly bar graph, college rankings, course rankings, class composition area graph, district bar chart, year × district heatmap, branch treemap.
- Separate B.Tech and Degree analytics with more charts.
- Filter by academic year 2020–2026, college type, district, college, branch, study year, section.
- Male and female totals separately, year-wise student counts, section A/B/C and class 1–4 (degree four-year demo begins in 2024).
- Download class breakdowns, filtered data, separate CSV files, and the multi-sheet XLSX.
- Responsive dark-glass dashboard with accessible high-contrast labels.

## Replacing demo data

The Streamlit app reads files from the `data/` directory. You can replace the CSV records with verified, aggregated, non-personal data. Keep the same column headers and matching `college_id`/`program_id` IDs.

To rebuild the **fictional** demo CSVs, run:

```bash
python generate_dataset.py
```

**Caution:** This replaces CSVs only and will not update the existing Excel workbook. Regenerate the workbook separately if you need both formats synchronized.

## Next step for official research

For a genuinely complete Andhra Pradesh institution-wide dashboard, import the live AP admissions institute-course registers for the relevant academic year, and obtain authorized student counts for each year/branch/class. Do not infer real enrollments from intake capacities; offered seats are not actual attendance.

## Additional separately packaged data files

For users who want the two college types kept distinct, the `data/` directory also contains:

| B.Tech files | Degree files |
|---|---|
| `BTech_colleges.csv` | `Degree_colleges.csv` |
| `BTech_courses.csv` | `Degree_courses.csv` |
| `BTech_enrollments_2020_2026.csv` | `Degree_enrollments_2020_2026.csv` |

Separate year-wise summaries are supplied in `college_year_gender_summary.csv`, `branch_year_gender_summary.csv`, and `district_year_gender_summary.csv`. Each has male and female counts in distinct columns, ready for analysis. These counts remain fictional demo values.
