"""Andhra Pradesh Higher Education Intelligence — B.Tech + Degree (2020–2026).
Run: streamlit run app.py
Demo records (especially enrollment and course-college relations) are SYNTHETIC.
"""
from pathlib import Path
import io
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

BASE=Path(__file__).resolve().parent
DATA=BASE/'data'
st.set_page_config(page_title='AP | Higher Education Intelligence',page_icon='🎓',layout='wide',initial_sidebar_state='expanded')
BLUE='#5B8CFF'; CYAN='#26D9D2'; VIOLET='#B18BFF'; ORANGE='#FFB36E'; RED='#FF789C'
GENDER={'Male':BLUE,'Female':RED}
TYPE={'B.Tech':CYAN,'Degree':VIOLET}
COLORS=[BLUE,CYAN,VIOLET,ORANGE,RED,'#79D8AC','#EBCA77','#A6B5FF']
PLOT='plotly_dark'
st.markdown('''<style>
[data-testid="stAppViewContainer"]{background:radial-gradient(ellipse at 90% -12%,#142e52 0%,#0a1424 42%,#090f1a 100%);color:#e9f2ff}
[data-testid="stSidebar"]{background:#0b1626;border-right:1px solid #233b57}
[data-testid="stHeader"]{background:transparent}
h1,h2,h3{color:#f2f7ff!important;letter-spacing:-.025em}
p,span,label,small{color:inherit}
.block-container{padding-top:1.1rem;max-width:1550px}
.hero{padding:23px 27px;border:1px solid #294667;background:linear-gradient(104deg,#122b4b,#122136 58%,#183248);border-radius:20px;margin:0 0 20px}
.hero-title{font-size:2rem;line-height:1.14;font-weight:850;color:#f6faff;letter-spacing:-.035em}
.hero-sub{color:#b9cde0;font-size:1rem;margin-top:10px;max-width:960px}
.eyebrow{font-size:.72rem;letter-spacing:.2em;font-weight:800;color:#62e3de}
.metric-card{background:linear-gradient(140deg,#172b43,#101e30);border:1px solid #29415f;border-radius:16px;padding:18px 18px;min-height:118px}
.metric-label{color:#b7c8d9;font-size:.77rem;letter-spacing:.06em;font-weight:680}
.metric-value{color:white;font-size:1.78rem;font-weight:800;margin-top:9px}
.metric-note{font-size:.72rem;color:#87a9c8;margin-top:4px}
.notice{padding:11px 15px;border:1px solid #72542c;background:#292316;color:#ffdba0;border-radius:11px;margin-bottom:18px;font-size:.88rem}
.sectionlabel{font-size:1.19rem;font-weight:750;color:#eff7ff;margin:16px 0 10px}
div[data-testid="stDataFrame"]{border-radius:12px;overflow:hidden}
[data-testid="stSidebar"] .stMarkdown p{color:#c2d3e6}
.stButton>button,.stDownloadButton>button{border:1px solid #41638f;background:#142a46;color:#eaf6ff;border-radius:11px}
</style>''', unsafe_allow_html=True)

@st.cache_data(show_spinner=False)
def load_data():
    c=pd.read_csv(DATA/'colleges.csv',encoding='utf-8-sig',dtype={'college_id':'string'})
    p=pd.read_csv(DATA/'programs.csv',encoding='utf-8-sig',dtype={'college_id':'string','program_id':'string'})
    e=pd.read_csv(DATA/'enrollments_2020_2026.csv',encoding='utf-8-sig',dtype={'college_id':'string','program_id':'string'})
    d=e.merge(p[['program_id','branch_code','branch_name']],on='program_id',validate='many_to_one')
    d=d.merge(c[['college_id','college_name','college_type','district','city','campus_type']],on='college_id',validate='many_to_one')
    for n in ['academic_year','study_year','male','female','total']:d[n]=pd.to_numeric(d[n],errors='coerce').fillna(0).astype(int)
    return c,p,d

try:colleges,programs,all_data=load_data()
except Exception as exc:
    st.error('Data files were not found or could not be opened. Keep the data folder next to app.py and run `python generate_dataset.py` if needed.')
    st.exception(exc)
    st.stop()

# All filters are applied to all analytical views. Blanks in multiselect = ALL.
st.sidebar.markdown('## 🎓 AP Education IQ')
st.sidebar.caption('Interactive college analytics | 2020–2026')
st.sidebar.divider()
page=st.sidebar.radio('Workspace',[
    '📊 Executive Overview','🛠️ B.Tech Analytics','📚 Degree Analytics',
    '🏫 College Directory','🧑‍🎓 Class & Section Insights','🗂️ Dataset Explorer','ℹ️ Methodology'
],index=0)
st.sidebar.divider()
st.sidebar.markdown('### Advanced filters')
start,end=st.sidebar.select_slider('Academic year range',options=list(range(2020,2027)),value=(2020,2026))
selected_types=st.sidebar.multiselect('Institution category',['B.Tech','Degree'],default=['B.Tech','Degree'])
allowed_c=colleges[colleges.college_type.isin(selected_types)]
districts=sorted(allowed_c.district.unique().tolist())
selected_districts=st.sidebar.multiselect('District (blank = all)',districts,default=[])
if selected_districts:allowed_c=allowed_c[allowed_c.district.isin(selected_districts)]
college_options=allowed_c.sort_values('college_name')[['college_id','college_name']]
college_choice=st.sidebar.multiselect('College (blank = all)',college_options.college_id.tolist(),
    format_func=lambda x:college_options.set_index('college_id').college_name.to_dict().get(x,x),default=[])
if college_choice:allowed_c=allowed_c[allowed_c.college_id.isin(college_choice)]
program_options=programs[programs.college_id.isin(allowed_c.college_id)]
branch_labels=sorted(program_options.branch_name.unique().tolist())
chosen_branches=st.sidebar.multiselect('Course / branch (blank = all)',branch_labels,default=[])
study_choices=st.sidebar.multiselect('Study year / class',options=[1,2,3,4],default=[1,2,3,4],
    format_func=lambda x:f'Year {x}')
selected_sections=st.sidebar.multiselect('Section',options=['A','B','C'],default=['A','B','C'])

filtered=all_data[
    all_data.college_id.isin(allowed_c.college_id) &
    all_data.academic_year.between(start,end) &
    all_data.study_year.isin(study_choices) &
    all_data.section.isin(selected_sections)
].copy()
if chosen_branches:filtered=filtered[filtered.branch_name.isin(chosen_branches)]

st.sidebar.caption('⚠️ All student counts and college–course associations are synthetic demo data. College directory is curated and not exhaustive.')


def fig_style(fig,height=395,legend=True):
    fig.update_layout(template=PLOT,paper_bgcolor='rgba(0,0,0,0)',plot_bgcolor='rgba(0,0,0,0)',
        font=dict(color='#e2efff',family='Arial',size=12),height=height,
        margin=dict(l=14,r=15,t=58,b=22),
        title_font=dict(size=17,color='#f3f8ff'),
        legend=dict(orientation='h',yanchor='bottom',y=1.02,xanchor='right',x=1),
        hoverlabel=dict(bgcolor='#223451',font_color='white'))
    fig.update_xaxes(showgrid=False,zeroline=False,tickfont=dict(color='#c8d8ea'))
    fig.update_yaxes(gridcolor='rgba(165,191,220,0.11)',zeroline=False,tickfont=dict(color='#c8d8ea'))
    if not legend:fig.update_layout(showlegend=False)
    return fig

def chart(fig,key=None):st.plotly_chart(fig,use_container_width=True,config={'displaylogo':False,'responsive':True},key=key)

def metric(label,value,note):
    st.markdown(f'<div class="metric-card"><div class="metric-label">{label}</div><div class="metric-value">{value}</div><div class="metric-note">{note}</div></div>',unsafe_allow_html=True)

def summary(data):
    cards=st.columns(5)
    kpis=[('STUDENTS (DEMO)',f'{data.total.sum():,}','Cumulative record total'),
          ('MALE (DEMO)',f'{data.male.sum():,}','Synthetic male counts'),
          ('FEMALE (DEMO)',f'{data.female.sum():,}','Synthetic female counts'),
          ('COLLEGE EXAMPLES',f'{data.college_id.nunique():,}','Filtered directory'),
          ('COURSE OFFERINGS',f'{data.program_id.nunique():,}','Illustrative associations')]
    for col,(label,val,note) in zip(cards,kpis):
        with col:metric(label,val,note)

def filter_header(title,subtitle):
    st.markdown(f'<div class="hero"><div class="eyebrow">ANDHRA PRADESH • EDUCATION INTELLIGENCE</div><div class="hero-title">{title}</div><div class="hero-sub">{subtitle}</div></div>',unsafe_allow_html=True)
    st.markdown('<div class="notice"><b>DATA TRANSPARENCY:</b> All 2020–2026 enrollments, male/female figures, sections and program assignments are generated demonstration data, not actual college or government statistics. The college directory is a partial, illustrative list.</div>',unsafe_allow_html=True)

def trend(data):
    a=data.groupby('academic_year',as_index=False)[['male','female','total']].sum()
    stacked=a.melt('academic_year',value_vars=['male','female'],var_name='Gender',value_name='Students')
    stacked.Gender=stacked.Gender.str.title()
    f=px.bar(stacked,x='academic_year',y='Students',color='Gender',barmode='stack',
             color_discrete_map=GENDER,title='Gender-wise enrollment trend • 2020–2026',text_auto='.2s')
    f.update_xaxes(dtick=1,title='Academic year (start)')
    return fig_style(f)

def donut(data):
    g=pd.DataFrame({'Gender':['Male','Female'],'Count':[int(data.male.sum()),int(data.female.sum())]})
    f=px.pie(g,names='Gender',values='Count',hole=.68,title='Male / female split',
             color='Gender',color_discrete_map=GENDER)
    f.update_traces(textinfo='percent+label',textfont_size=13,pull=[0.025,0.025],marker=dict(line=dict(color='#101a2a',width=3)))
    f.add_annotation(text=f'<b>{g.Count.sum():,}</b><br><span style="font-size:12px">demo records</span>',x=.5,y=.5,
                     xref='paper',yref='paper',showarrow=False,font=dict(size=18,color='#eaf6ff'))
    return fig_style(f)

def college_ranking(data):
    t=data.groupby(['college_name','college_type'],as_index=False).total.sum().nlargest(12,'total').sort_values('total')
    f=px.bar(t,x='total',y='college_name',orientation='h',color='college_type',
             color_discrete_map=TYPE,title='Top 12 sample colleges by demo enrollments',
             labels={'total':'Students (synthetic)','college_name':'College','college_type':'Category'})
    f.update_layout(yaxis=dict(automargin=True),margin=dict(l=12,r=10,t=62,b=18))
    return fig_style(f,480)

def course_chart(data):
    t=data.groupby(['branch_name','college_type'],as_index=False).total.sum().nlargest(14,'total').sort_values('total')
    f=px.bar(t,x='total',y='branch_name',orientation='h',color='college_type',color_discrete_map=TYPE,
             title='Most represented courses / branches',labels={'total':'Students (synthetic)','branch_name':'Course','college_type':'Category'})
    f.update_layout(yaxis=dict(automargin=True))
    return fig_style(f,485)

def heatmap(data):
    t=data.groupby(['district','academic_year'],as_index=False).total.sum()
    top=t.groupby('district').total.sum().nlargest(16).index
    t=t[t.district.isin(top)]
    pv=t.pivot(index='district',columns='academic_year',values='total').fillna(0).sort_index()
    f=px.imshow(pv,aspect='auto',text_auto=False,color_continuous_scale=['#182c47','#265989','#1e9fa5','#6ce6d8'],
                title='District × year enrollment density (synthetic)',labels={'x':'Academic year','y':'District','color':'Students'})
    f.update_layout(coloraxis_colorbar=dict(title='Count'))
    return fig_style(f,490)

def year_class(data):
    t=data.groupby(['academic_year','study_year'],as_index=False).total.sum()
    t['Study year']=t.study_year.map(lambda x:f'Year {x}')
    f=px.area(t,x='academic_year',y='total',color='Study year',title='Class-year composition over time',
              color_discrete_sequence=COLORS,labels={'total':'Students (synthetic)','academic_year':'Academic year'})
    f.update_xaxes(dtick=1)
    return fig_style(f)

def district_bars(data):
    t=data.groupby(['district','college_type'],as_index=False).total.sum()
    top=data.groupby('district').total.sum().nlargest(12).index.tolist()
    t=t[t.district.isin(top)]
    f=px.bar(t,x='district',y='total',color='college_type',barmode='group',
             color_discrete_map=TYPE,title='District-wise comparison • Degree vs B.Tech',
             labels={'total':'Students (synthetic)','district':'District','college_type':'Category'})
    f.update_xaxes(tickangle=-35)
    return fig_style(f,450)

def study_year_gender(data):
    a=data.groupby('study_year',as_index=False)[['male','female']].sum()
    b=a.melt('study_year',value_vars=['male','female'],var_name='Gender',value_name='Students')
    b.Gender=b.Gender.str.title()
    b['Class']=b.study_year.map(lambda n:f'Year {n}')
    f=px.bar(b,x='Class',y='Students',color='Gender',barmode='group',
             title='Male and female split by year of study',color_discrete_map=GENDER)
    return fig_style(f)

def section_chart(data):
    a=data.groupby(['section','study_year'],as_index=False).total.sum()
    a['Class']=a.study_year.map(lambda x:f'Year {x}')
    f=px.bar(a,x='Class',y='total',color='section',barmode='stack',title='Section A / B / C • class breakdown',
             color_discrete_sequence=[BLUE,CYAN,VIOLET],labels={'total':'Students (synthetic)','section':'Section'})
    return fig_style(f)

def treemap(data):
    a=data.groupby(['college_type','district','branch_name'],as_index=False).total.sum()
    f=px.treemap(a,path=['college_type','district','branch_name'],values='total',color='total',
                 title='Course mix • category → district → branch',
                 color_continuous_scale=['#183753','#276c94','#37b9c0','#b8ffdc'])
    f.update_traces(root_color='#102038')
    return fig_style(f,495)

if page=='📊 Executive Overview':
    filter_header('AP Higher Education Intelligence','Premium interactive analytics for Degree and B.Tech college examples • trend analysis, branch statistics, classroom sections and gender breakdowns from 2020–2026.')
    if filtered.empty:st.warning('No data matches these filters. Clear a few sidebar selections.');st.stop()
    summary(filtered)
    st.markdown('#### Statewide sample dashboard')
    l,r=st.columns([1.65,1])
    with l:chart(trend(filtered))
    with r:chart(donut(filtered))
    a,b=st.columns(2)
    with a:chart(district_bars(filtered))
    with b:chart(year_class(filtered))
    a,b=st.columns(2)
    with a:chart(college_ranking(filtered))
    with b:chart(course_chart(filtered))
    chart(heatmap(filtered))
    chart(treemap(filtered))

elif page in ('🛠️ B.Tech Analytics','📚 Degree Analytics'):
    target='B.Tech' if 'B.Tech' in page else 'Degree'
    d=filtered[filtered.college_type.eq(target)]
    filter_header(f'{target} College Analytics',f'Explore {target} college examples, branches, class sections, year-wise records and gender comparisons. All charts respect the sidebar filters.')
    if d.empty:st.warning('No matching records for this category and filters.');st.stop()
    summary(d)
    a,b=st.columns([1.55,1])
    with a:chart(trend(d))
    with b:chart(donut(d))
    a,b=st.columns(2)
    with a:chart(course_chart(d))
    with b:chart(college_ranking(d))
    a,b=st.columns(2)
    with a:chart(study_year_gender(d))
    with b:chart(section_chart(d))
    chart(heatmap(d))

elif page=='🏫 College Directory':
    filter_header('College & Course Directory','Separate engineering and degree lists, 2026 district labels, illustrative courses and curated source information.')
    selected=colleges[colleges.college_id.isin(allowed_c.college_id)]
    if college_choice:selected=selected[selected.college_id.isin(college_choice)]
    if chosen_branches:
        matching=programs[programs.branch_name.isin(chosen_branches)]
        selected=selected[selected.college_id.isin(matching.college_id)]
    st.markdown(f'### {len(selected)} selected college examples • B.Tech: {sum(selected.college_type=="B.Tech")} • Degree: {sum(selected.college_type=="Degree")}')
    eng,deg=st.tabs(['⚙️ B.Tech colleges','📖 Degree colleges'])
    columns=['college_id','college_name','district','city','campus_type']
    for tab,kind in [(eng,'B.Tech'),(deg,'Degree')]:
        with tab:
            subset=selected[selected.college_type.eq(kind)][columns].sort_values('district')
            st.dataframe(subset,use_container_width=True,hide_index=True,height=390)
            st.download_button(f'Download {kind} college list (CSV)',subset.to_csv(index=False).encode('utf-8-sig'),
                               file_name=f'{kind.lower().replace(".","").replace(" ","_")}_colleges.csv',mime='text/csv')
    st.markdown('#### College → example branch lookup')
    if selected.empty:st.info('No colleges match the selected filters.')
    else:
        cid=st.selectbox('Select an institution',selected.college_id.tolist(),
            format_func=lambda x:colleges.set_index('college_id').at[x,'college_name'])
        info=colleges.set_index('college_id').loc[cid]
        st.write(f'**{info.college_name}** | **{info.college_type}** | {info.district} | {info.city} | {info.campus_type}')
        st.info('The courses below are SAMPLE course assignments; they must be confirmed from the institution’s current course catalog.')
        st.dataframe(programs[programs.college_id.eq(cid)][['branch_code','branch_name','verification_note']],hide_index=True,use_container_width=True)
        st.markdown(f'[Official AP listing portal for cross-checking]({info.source_url})')

elif page=='🧑‍🎓 Class & Section Insights':
    filter_header('Classroom & Gender Analytics','Drill down by academic year, class/year of study, section A/B/C, course and college — separate male/female demo records.')
    if filtered.empty:st.warning('No data matches these filters.');st.stop()
    summary(filtered)
    a,b=st.columns(2)
    with a:chart(study_year_gender(filtered))
    with b:chart(section_chart(filtered))
    a,b=st.columns(2)
    with a:chart(year_class(filtered))
    with b:chart(course_chart(filtered))
    st.markdown('#### Expandable class ledger')
    t=filtered.groupby(['academic_year','college_type','district','college_name','branch_name','study_year','section'],as_index=False)[['male','female','total']].sum()
    t=t.rename(columns={'academic_year':'Year','college_type':'Type','district':'District','college_name':'College','branch_name':'Branch','study_year':'Study Year','section':'Section','male':'Male','female':'Female','total':'Total'})
    st.dataframe(t,use_container_width=True,hide_index=True,height=430)
    st.download_button('Download filtered class ledger (CSV)',t.to_csv(index=False).encode('utf-8-sig'),file_name='AP_class_gender_filtered.csv',mime='text/csv')

elif page=='🗂️ Dataset Explorer':
    filter_header('Data Lab & Dataset Downloads','Access separate CSV datasets and a complete Excel workbook. Export filtered records for your project report or update the original files with verified data.')
    if filtered.empty:st.info('The current filters return zero student rows. The full datasets remain available below.')
    d=filtered.copy()
    st.markdown('### Filtered student enrollment records')
    st.dataframe(d[['academic_year','college_type','district','college_name','branch_name','study_year','section','male','female','total']],
                 use_container_width=True,hide_index=True,height=380)
    st.download_button('Download currently filtered student records',d.to_csv(index=False).encode('utf-8-sig'),file_name='ap_filtered_demo_students.csv',mime='text/csv')
    st.markdown('### Download individual datasets')
    files=[('College directory','colleges.csv'),('Illustrative college-course list','programs.csv'),
           ('Male/female + class records, 2020–2026','enrollments_2020_2026.csv'),
           ('28 AP districts','districts.csv'),('Data dictionary / metadata','data_dictionary.csv'),
           ('B.Tech college list','BTech_colleges.csv'),('Degree college list','Degree_colleges.csv'),
           ('B.Tech branch examples','BTech_courses.csv'),('Degree course examples','Degree_courses.csv'),
           ('B.Tech enrollment ledger','BTech_enrollments_2020_2026.csv'),
           ('Degree enrollment ledger','Degree_enrollments_2020_2026.csv'),
           ('College-year gender summary','college_year_gender_summary.csv'),
           ('Branch-year gender summary','branch_year_gender_summary.csv'),
           ('District-year gender summary','district_year_gender_summary.csv')]
    for index,(label,filename) in enumerate(files):
        c1,c2=st.columns([4,1])
        with c1:st.write(f'**{label}** — `{filename}`')
        with c2:st.download_button('Download CSV',(DATA/filename).read_bytes(),file_name=filename,mime='text/csv',key=f'csv{index}')
    excel=DATA/'AP_College_Dashboard_Dataset_2020_2026.xlsx'
    if excel.is_file():
        st.download_button('📥 Download all sheets in Excel (.xlsx)',excel.read_bytes(),file_name=excel.name,
                           mime='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')

else:
    filter_header('Methodology & Source Transparency','How the dataset was created, what is real vs illustrative, and how to replace it with verified school-year statistics.')
    st.markdown('''### What is and is not official
**College names:** A non-exhaustive, curated list of real-name examples to demonstrate the dashboard. Names, statuses, and 2026 districts should be cross-checked against current institutional registers.

**College to branch relationships:** Fictional demonstration associations. A college appearing with a branch in this app does **not** verify it offers that course.

**Student counts (male/female), 2020–2026, study years and sections:** 100% synthetically generated. These figures must **never** be quoted as actual Andhra Pradesh historical college enrollments, government reporting, or admissions data.

**Academic year:** `2020` denotes 2020–21, through `2026` for 2026–27. Earlier years are assigned to the *current 2026 district labels* for a consistent example dashboard rather than historical district boundaries.

**Class types:** Study years 1, 2, 3, 4; sections A, B, C. These classes are examples and do not claim to reflect the actual timetable of any institution.''')
    st.markdown('### Links to original institutional sources')
    st.markdown('''- [Government of AP Common Admissions Portal — 2026](https://cap.apcfss.in/DashboardHome)
- [APSCHE Degree Institute-wise Course Listing](https://oamdc.ucanapply.com/institute-wise-courses?appid=OAMDC)
- [AP EAPCET official site](https://cets.apsche.ap.gov.in/EAPCET/Eapcet/EAPCET_HomePage)
- [Government directory of Andhra Pradesh districts](https://igod.gov.in/sg/AP/E042/organizations)''')
    st.markdown('### Replace the example values with real data')
    st.markdown('''1. Keep the same CSV column names and IDs in `colleges.csv`, `programs.csv`, and `enrollments_2020_2026.csv`.
2. Replace college and course lists with current official listings and verified college-course associations.
3. Replace synthetic male/female records with properly sourced aggregated class/student figures after confirming permission to use them.
4. Make sure `total = male + female` for this example two-category reporting system, or extend the schema if your real reporting categories differ.
5. Restart Streamlit or click **Clear cache** in the app menu after editing the CSV files.''')
    st.caption('Technical stack: Python • Streamlit • pandas • Plotly Express / Graph Objects • CSV / Excel. Demo generated with a fixed random seed for reproducibility.')

st.markdown('---')
st.caption(f'AP Education IQ • Academic years {start}–{end} • Curated directory + SYNTHETIC sample dataset • Not an official APSCHE report')
